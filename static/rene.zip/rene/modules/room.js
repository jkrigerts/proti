let NUMBER_OF_ROWS = 4;
let NUMBER_OF_COLUMNS = 4;
let BOX_POSITION = "2-2";

export function getRows() {
  return NUMBER_OF_ROWS;
}

export function getCols() {
  return NUMBER_OF_COLUMNS;
}

function createRoom() {
  const room = document.getElementById("room");

  // Create entities in the room.
  for (let i = 0; i < NUMBER_OF_ROWS; i++) {
    for (let j = 0; j < NUMBER_OF_COLUMNS; j++) {
      const entity = document.createElement("div");
      entity.id = `${i}-${j}`;
      entity.classList.add("entity");
      room.appendChild(entity);
    }
  }
  room.style.gridTemplateColumns = `repeat(${NUMBER_OF_COLUMNS}, minmax(0, 1fr))`;
  room.style.gridTemplateRows = `repeat(${NUMBER_OF_ROWS}, minmax(0, 1fr))`;
}

export async function inWorkroom1() {
  NUMBER_OF_ROWS = 4;
  NUMBER_OF_COLUMNS = 4;
  BOX_POSITION = "3-3";
  createRoom();
  document.getElementById(BOX_POSITION).classList.add("box");
}

export async function inWorkroom2() {
  NUMBER_OF_ROWS = 4;
  NUMBER_OF_COLUMNS = 4;
  BOX_POSITION = "1-2";
  createRoom();
  document.getElementById(BOX_POSITION).classList.add("box");
}

export async function inWorkroom3() {
  NUMBER_OF_ROWS = 4;
  NUMBER_OF_COLUMNS = 4;
  BOX_POSITION = "3-3";
  createRoom();
  document.getElementById(BOX_POSITION).classList.add("box");
  document.getElementById("2-1").classList.add("target");
}

export function inWorkroom4() {
  NUMBER_OF_ROWS = 4;
  NUMBER_OF_COLUMNS = 4;
  BOX_POSITION = "2-2";
  createRoom();
  document.getElementById(BOX_POSITION).classList.add("box");
  document.getElementById("1-0").classList.add("target");
  document.getElementById("2-1").classList.add("obstacle");
  document.getElementById("2-0").classList.add("obstacle");
}

export function inWorkroom5() {
  NUMBER_OF_ROWS = 5;
  NUMBER_OF_COLUMNS = 5;
  BOX_POSITION = "1-4";
  createRoom();
  document.getElementById(BOX_POSITION).classList.add("box");
  document.getElementById("1-0").classList.add("target");
  document.getElementById("2-1").classList.add("obstacle");
  document.getElementById("3-1").classList.add("obstacle");
  document.getElementById("2-2").classList.add("obstacle");
  document.getElementById("2-3").classList.add("obstacle");
  document.getElementById("3-3").classList.add("obstacle");
  document.getElementById("0-3").classList.add("obstacle");
  document.getElementById("0-2").classList.add("obstacle");
}

export function inWorkroom6() {
  NUMBER_OF_ROWS = 5;
  NUMBER_OF_COLUMNS = 7;
  BOX_POSITION = "4-6";
  createRoom();
  document.getElementById(BOX_POSITION).classList.add("box");
  document.getElementById("3-0").classList.add("target");

  document.getElementById("1-1").classList.add("obstacle");
  document.getElementById("2-1").classList.add("obstacle");
  document.getElementById("3-1").classList.add("obstacle");
  document.getElementById("4-1").classList.add("obstacle");

  document.getElementById("0-3").classList.add("obstacle");
  document.getElementById("1-3").classList.add("obstacle");
  document.getElementById("2-3").classList.add("obstacle");
  document.getElementById("3-3").classList.add("obstacle");

  document.getElementById("1-5").classList.add("obstacle");
  document.getElementById("2-5").classList.add("obstacle");
  document.getElementById("3-5").classList.add("obstacle");
  document.getElementById("4-5").classList.add("obstacle");
}

export function inImageGallery(
  sourceURL = "https://images.unsplash.com/photo-1575361204480-aadea25e6e68?w=450"
) {
  NUMBER_OF_ROWS = 3;
  NUMBER_OF_COLUMNS = 3;
  BOX_POSITION = "1-1";
  createRoom();
  const imageFrame = document.getElementById(BOX_POSITION);
  document.getElementById("heading").textContent = "Rene in the Image Gallery";
  imageFrame.classList.add("artwork-frame");
  const image = document.createElement("img");
  image.src = sourceURL;
  imageFrame.appendChild(image);
  image.id = "artwork";
  console.log("augstums", image.height);
  image.crossOrigin = "anonymous";
}
