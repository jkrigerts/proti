import { inWorkroom1 } from "./modules/room.js";
import { move } from "./modules/rene.js";

inWorkroom1();