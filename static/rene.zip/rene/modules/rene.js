import { getRows, getCols } from "./room.js";

const directionMap = [
  [0, 1], // Looking right
  [1, 0], // Looking down
  [0, -1], // Looking left
  [-1, 0], // Looking up
];

let speed = 1000;
let reneRow = getRows() - 1;
let reneCol = 0;
let reneDirection = 0;
let countOfBoxesInBag = 0;

// Create Rene div and image
const rene = document.createElement("div");
const reneImage = document.createElement("img");
reneImage.src = "images/rene.png";
rene.id = "rene";
rene.appendChild(reneImage);

const room = document.getElementById("room");
const config = { childList: true };

function whenRoomCreated() {
  reneRow = getRows() - 1;
  const reneEntity = document.getElementById(`${reneRow}-${reneCol}`);
  console.log(reneEntity);
  reneEntity.appendChild(rene);
}
const observeRoomCreation = new MutationObserver(whenRoomCreated);
observeRoomCreation.observe(room, config);

export function setSpeed(oneDivSeconds) {
  speed = 1000 / oneDivSeconds;
}

function resetRene() {
  reneRow = getRows() - 1;
  reneCol = 0;
  reneDirection = 0;
  reneImage.style.transform = `rotate(0deg)`;
  const reneEntity = document.getElementById(`${reneRow}-${reneCol}`);
  reneEntity.appendChild(rene);
}

export async function move() {
  await new Promise((r) => setTimeout(r, speed));
  const renePrevEntity = document.getElementById(`${reneRow}-${reneCol}`);
  renePrevEntity.removeChild(rene);

  reneRow = reneRow + directionMap[reneDirection][0];
  reneCol = reneCol + directionMap[reneDirection][1];
  if (
    reneRow == getRows() ||
    reneCol == getCols() ||
    reneRow < 0 ||
    reneCol < 0
  ) {
    alert("Rene ran into a Wall!");
    resetRene();
    return;
  }
  const reneNextEntity = document.getElementById(`${reneRow}-${reneCol}`);

  if (reneNextEntity.classList.contains("obstacle")) {
    alert("Rene ran into an Obstacle!");
    resetRene();
    return;
  }
  reneNextEntity.appendChild(rene);
}

export async function turnRight() {
  await new Promise((r) => setTimeout(r, speed));
  reneDirection = reneDirection == 3 ? 0 : reneDirection + 1;
  if (reneDirection == 2) {
    reneImage.style.transform = `scaleX(-1)`;
    return;
  }
  reneImage.style.transform = `rotate(${reneDirection * 90}deg)`;
}

export async function pickUp() {
  await new Promise((r) => setTimeout(r, speed));
  const reneCurrentEntity = document.getElementById(`${reneRow}-${reneCol}`);
  if (reneCurrentEntity.classList.contains("box")) {
    reneCurrentEntity.classList.remove("box");
    countOfBoxesInBag++;
  }
}

export async function putDown() {
  await new Promise((r) => setTimeout(r, speed));
  if (countOfBoxesInBag == 0) {
    return;
  }
  const reneCurrentEntity = document.getElementById(`${reneRow}-${reneCol}`);
  reneCurrentEntity.classList.add("box");
  countOfBoxesInBag--;
  if (reneCurrentEntity.classList.contains("target")) {
    reneCurrentEntity.classList.remove("target");
    reneCurrentEntity.classList.add("achieved");

    const check = document.createElement("img");
    check.classList.add("checkmark");
    check.src = "images/check.webp";
    reneCurrentEntity.appendChild(check);
  }
}

export async function recognizeObjects() {
  const classifier = ml5.imageClassifier("MobileNet");

  const reneCurrentEntity = document.getElementById(`${reneRow}-${reneCol}`);
  if (reneCurrentEntity.classList.contains("artwork-frame")) {
    const callout = document.createElement("div");
    callout.id = "callout";
    callout.textContent = "I am thinking...";
    callout.classList.add("callout");
    rene.appendChild(callout);
    const artWork = document.getElementById("artwork");
    classifier.classify(artWork, gotResultFromClassifier);
  }

  function gotResultFromClassifier(error, results) {
    console.log("callout...");
    const callout = document.getElementById("callout");
    callout.textContent = error;
    callout.textContent = `I see a ${
      results[0].label
    } with confidence ${Math.round(results[0].confidence * 100)} %`;
  }
}
